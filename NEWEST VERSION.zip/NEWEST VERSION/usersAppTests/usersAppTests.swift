//
//  usersAppTests.swift
//  usersAppTests
//
//  Created by Sofija Zolotarev on 30.4.25..
//

import Testing
@testable import usersApp

struct usersAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
